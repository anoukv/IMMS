Remi de Zoeten 6308694
Anouk Visser 6277209

There are three demos:

demoHarris
demoOpt
generateVideos
