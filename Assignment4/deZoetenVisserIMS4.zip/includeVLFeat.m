% run this to include the vlfeat stuff

run('vlfeat/toolbox/vl_setup')