Rémi de Zoeten (6308694)
Anouk Visser (6277209)

This zip contains the source code for assignment 4. It also contains 5 images (PNG) showing the target image (which is img1.pgm in all cases), the initial image, the transformed image (alignment) and the transformed image using MATLAB's imtransform and maketform. 

To run the code you can run the two demos: 

demoAlignment()
demoStitch()

We assume that vl_feat is up and running (due to the filesize we did not include this in our zip). 
