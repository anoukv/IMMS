function Gd = gaussianDer(G,sigma)

%
%   Returns the gaussian derivative of G with sigma.
%

% this sigma should be the same as the sigma used to make G
% prepare data
size = round(3 * sigma);
x = -size:size;

% Perform calculation
Gd = (- x / sigma.^2) .* G;

end

